﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switchcase
{

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter 1 for red BG:");
            Console.WriteLine("enter 2 for green BG:");
            Console.WriteLine("enter 3 for yellow BG:");
            int i = Convert.ToInt32(Console.ReadLine());
            switch (i)
            {
                case 1:
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Clear();
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;
                case 3:
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.Clear();
                    break;

                default:
                    Console.Write("invalid case");
                    break;

            }
            Console.ReadLine();
        }
    }
}



